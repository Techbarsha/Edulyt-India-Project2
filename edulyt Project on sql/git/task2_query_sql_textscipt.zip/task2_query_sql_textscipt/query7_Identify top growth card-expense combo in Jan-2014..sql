use projectdb;
select * from credit_card;
WITH MonthlyGrowth AS (
    SELECT
        CardType,
        ExpType,
        Date,
        Amount,
        LAG(Amount) OVER (PARTITION BY CardType, ExpType ORDER BY Date) AS PreviousAmount
    FROM
        credit_card
    WHERE
        Date BETWEEN '01-Jan-14' AND '31-Jan-14'
)
SELECT
    CardType,
    ExpType,
    MAX((Amount - PreviousAmount) / PreviousAmount * 100) AS MaxMoMGrowth
FROM
    MonthlyGrowth
WHERE
    PreviousAmount IS NOT NULL
GROUP BY
    CardType, ExpType;
