use projectdb;
show tables;
select * from credit_card;
SELECT
    City,
    ROUND(SUM(Amount), 2) AS TotalSpends,
    ROUND(SUM(Amount) / (SELECT SUM(Amount) FROM credit_card) * 100, 2) AS PercentageContribution
FROM
    credit_card
GROUP BY
    City
ORDER BY
    TotalSpends DESC;

