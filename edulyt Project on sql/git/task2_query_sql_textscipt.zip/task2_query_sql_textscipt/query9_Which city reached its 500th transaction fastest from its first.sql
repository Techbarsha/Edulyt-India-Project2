create table credit_card(
index_no int,
city varchar(40),
transaction_date DATE,
card_type varchar(20), 
exp_type varchar(20),
gender varchar(10),
amount int
)

select * from credit_card
drop table credit_card


WITH city_transactions AS (
    SELECT 
        city,
        MIN(transaction_date) AS first_transaction_date,
        COUNT(*) AS total_transactions
    FROM 
        credit_card
    GROUP BY 
        city
),
five_hundredth_transaction_per_city AS (
    SELECT 
        city,
        MIN(transaction_date) AS five_hundredth_transaction_date
    FROM 
        (
            SELECT 
                city,
                transaction_date,
                ROW_NUMBER() OVER(PARTITION BY city ORDER BY transaction_date) AS transaction_count
            FROM 
                credit_card
        ) AS ranked_transactions
    WHERE 
        transaction_count = 500
    GROUP BY 
        city
)
SELECT 
    city_transactions.city,
    (five_hundredth_transaction_per_city.five_hundredth_transaction_date - city_transactions.first_transaction_date) AS shortes_days_to_reach_500th_transaction
FROM 
    city_transactions
INNER JOIN 
    five_hundredth_transaction_per_city 
ON 
    city_transactions.city = five_hundredth_transaction_per_city.city
ORDER BY 
    shortes_days_to_reach_500th_transaction
	LIMIT 1;















select * from credit_card
drop table credit_card