use projectdb;
select * from credit_card;
SELECT
    ExpType,
    ROUND(SUM(CASE WHEN Gender = 'F' THEN Amount ELSE 0 END) / SUM(Amount) * 100, 2) AS PercentageContribution
FROM
    credit_card
GROUP BY
    ExpType;
