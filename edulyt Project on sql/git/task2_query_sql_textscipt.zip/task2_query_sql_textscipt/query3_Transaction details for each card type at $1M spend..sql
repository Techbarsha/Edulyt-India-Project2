use projectdb;
select * from credit_card;
SELECT City,
       (SUM(Amount) / (SELECT SUM(Amount) FROM credit_card)) * 100 AS PercentageSpend
FROM credit_card
WHERE CardType = 'Gold'
GROUP BY City
ORDER BY PercentageSpend ASC;

