select * from credit_card


SELECT card_type,
       MAX(amount) AS highest_amount,
       (SELECT transaction_date
        FROM credit_card
        WHERE card_type = t.card_type
        GROUP BY transaction_date
        ORDER BY SUM(amount) DESC
        LIMIT 1) AS highest_spend_month
FROM credit_card t
GROUP BY card_type;

SELECT card_type,
       MAX(amount) AS highest_amount,
       EXTRACT(MONTH FROM (SELECT transaction_date
                           FROM credit_card
                           WHERE card_type = t.card_type
                           GROUP BY transaction_date
                           ORDER BY SUM(amount) DESC
                           LIMIT 1)) AS highest_spend_month
FROM credit_card t
GROUP BY card_type;

