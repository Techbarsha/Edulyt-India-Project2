use projectdb;
select * from credit_card;
SELECT
    City,
    MAX(ExpType) AS highest_expense_type,
    MIN(ExpType) AS lowest_expense_type
FROM
    credit_card
GROUP BY
    City;