use projectdb;
show tables;
select * from credit_card;
SELECT 
    City,
    SUM(Amount) / COUNT(*) AS spend_to_transaction_ratio
FROM 
    credit_card 
    group by city
;
